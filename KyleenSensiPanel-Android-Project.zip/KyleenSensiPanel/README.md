# Kyleen Sensi Panel (Android)

Aplikasi Android native sederhana dengan branding **By Kyleen**. Ini bukan website.

## Fitur
- Panel gelap dengan aksen magenta
- Pilihan profil sensitivitas
- Slider General, Red Dot, Scope 2x, Scope 4x, Sniper, Free Look
- Simpan nilai lokal di perangkat
- Salin ringkasan konfigurasi
- Reset ke nilai default

## Cara membuat APK
1. Buka folder `KyleenSensiPanel` menggunakan Android Studio versi terbaru.
2. Tunggu Gradle Sync selesai (memerlukan internet saat pertama kali untuk mengambil Android Gradle Plugin).
3. Pilih **Build > Build APK(s)**.
4. APK debug akan muncul di `app/build/outputs/apk/debug/app-debug.apk`.

## Batasan
Aplikasi ini menyimpan dan menampilkan rekomendasi sensitivitas saja. Aplikasi tidak menyuntikkan kode ke Free Fire, tidak mengubah file game, tidak menggerakkan bidikan, dan tidak dapat menjamin headshot atau rasio headshot tertentu. Terapkan nilai secara manual pada pengaturan game.

## Build APK tanpa komputer (pakai HP melalui GitHub Actions)
Proyek menyertakan workflow `.github/workflows/build-apk.yml` untuk membuat APK di cloud GitHub.
1. Di browser HP, masuk ke GitHub dan buat repository baru.
2. Unggah isi folder proyek ini ke repository (pastikan folder `.github/workflows` ikut terunggah).
3. Buka tab **Actions**, pilih **Build Kyleen Sensi Panel APK**, lalu tekan **Run workflow** jika build tidak otomatis berjalan.
4. Setelah workflow selesai dengan status hijau, buka hasil run dan unduh artifact **KyleenSensiPanel-APK**.
5. Ekstrak artifact ZIP untuk mendapatkan `app-debug.apk`, lalu buka APK itu di HP dan izinkan pemasangan dari sumber tersebut bila Android memintanya.

Catatan: GitHub mungkin memerlukan verifikasi akun. APK debug ini belum ditandatangani sebagai rilis Play Store.
