package com.kyleen.sensipanel;

import android.app.Activity;
import android.os.Bundle;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.LinkedHashMap;
import java.util.Map;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9,9,16), CARD = Color.rgb(22,20,30), PINK = Color.rgb(255,22,143), WHITE = Color.WHITE, MUTED = Color.rgb(177,170,190);
    private final String[] names = {"General", "Red Dot", "Scope 2x", "Scope 4x", "Sniper", "Free Look"};
    private final Map<String, SeekBar> sliders = new LinkedHashMap<>();
    private TextView status;
    private android.content.SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("kyleen_sensi", MODE_PRIVATE);
        buildUi();
    }

    private GradientDrawable shape(int color, int radius, int strokeColor) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(radius);
        if (strokeColor != 0) d.setStroke(dp(1), strokeColor); return d;
    }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private LinearLayout column() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private LinearLayout.LayoutParams lp(int w, int h) { return new LinearLayout.LayoutParams(w < 0 ? w : dp(w), h < 0 ? h : dp(h)); }
    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(BG);
        LinearLayout root = column(); root.setPadding(dp(18), dp(22), dp(18), dp(26)); scroll.addView(root);
        TextView brand = text("KYLEEN  /  SENSI PANEL", 12, PINK, true); brand.setLetterSpacing(.12f); root.addView(brand);
        TextView title = text("FREE FIRE\nCONTROL CENTER", 27, WHITE, true); title.setPadding(0,dp(10),0,dp(4)); root.addView(title);
        TextView sub = text("Atur profil sensitivitasmu", 14, MUTED, false); root.addView(sub);
        LinearLayout badge = new LinearLayout(this); badge.setGravity(Gravity.CENTER_VERTICAL); badge.setPadding(dp(12),dp(10),dp(12),dp(10)); badge.setBackground(shape(CARD,dp(12),0));
        TextView dot = text("●", 13, PINK, true); badge.addView(dot); TextView state = text("  PANEL AKTIF  •  KONFIGURASI LOKAL", 11, WHITE, true); badge.addView(state); LinearLayout.LayoutParams bp=lp(-1,-2); bp.topMargin=dp(18); root.addView(badge,bp);
        TextView profileLabel = text("PILIH PROFIL", 11, MUTED, true); profileLabel.setPadding(0,dp(20),0,dp(8)); root.addView(profileLabel);
        Spinner profile = new Spinner(this); String[] profiles={"Balanced • Harian", "Drag Headshot • Manual", "Low Sensitivity", "High Sensitivity"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, profiles); profile.setAdapter(adapter);
        profile.setBackground(shape(CARD,dp(10),Color.rgb(62,48,67))); root.addView(profile,lp(-1,48));
        profile.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){ public void onNothingSelected(android.widget.AdapterView<?> p){} public void onItemSelected(android.widget.AdapterView<?> p, View v,int pos,long id){
            int[][] vals={{90,85,80,75,50,70},{96,92,85,80,55,70},{70,65,60,55,35,60},{100,95,90,85,65,80}};
            for(int i=0;i<names.length;i++){ SeekBar sb=sliders.get(names[i]); if(sb!=null) sb.setProgress(vals[pos][i]); }
        }});
        TextView section = text("SENSITIVITY", 12, PINK, true); section.setPadding(0,dp(22),0,dp(8)); root.addView(section);
        for (String n : names) addSlider(root,n);
        TextView note = text("Catatan: nilai ini adalah rekomendasi untuk kamu atur manual di pengaturan game. Aplikasi tidak mengubah file/game, tidak mengunci bidikan ke kepala, dan tidak menjamin persentase headshot.", 12, MUTED, false);
        note.setPadding(dp(12),dp(12),dp(12),dp(12)); note.setBackground(shape(CARD,dp(10),0)); LinearLayout.LayoutParams np=lp(-1,-2); np.topMargin=dp(16); root.addView(note,np);
        Button save = button("SIMPAN KONFIGURASI"); LinearLayout.LayoutParams sp=lp(-1,50); sp.topMargin=dp(16); root.addView(save,sp);
        Button copy = button("SALIN RINGKASAN"); LinearLayout.LayoutParams cp=lp(-1,48); cp.topMargin=dp(8); root.addView(copy,cp);
        Button reset = button("RESET NILAI"); reset.setBackground(shape(CARD,dp(12),Color.rgb(62,48,67))); LinearLayout.LayoutParams rp=lp(-1,48); rp.topMargin=dp(8); root.addView(reset,rp);
        status = text("By Kyleen  •  Versi 1.0", 11, MUTED, false); status.setGravity(Gravity.CENTER); LinearLayout.LayoutParams st=lp(-1,-2); st.topMargin=dp(20); root.addView(status,st);
        save.setOnClickListener(v->{ for(String n:names) prefs.edit().putInt(n,sliders.get(n).getProgress()).apply(); status.setText("✓ Konfigurasi tersimpan di perangkat"); Toast.makeText(this,"Konfigurasi disimpan",Toast.LENGTH_SHORT).show(); });
        copy.setOnClickListener(v->{ StringBuilder s=new StringBuilder("KYLEEN SENSI PANEL\n"); for(String n:names)s.append(n).append(": ").append(sliders.get(n).getProgress()).append("\n"); ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("Sensi By Kyleen",s.toString())); Toast.makeText(this,"Ringkasan disalin",Toast.LENGTH_SHORT).show(); });
        reset.setOnClickListener(v->{ int[] vals={90,85,80,75,50,70}; for(int i=0;i<names.length;i++)sliders.get(names[i]).setProgress(vals[i]); status.setText("Nilai kembali ke default"); });
        setContentView(scroll);
        for(String n:names){int val=prefs.getInt(n,-1); if(val>=0)sliders.get(n).setProgress(val);}
    }
    private void addSlider(LinearLayout root, String name) {
        LinearLayout card=column(); card.setPadding(dp(12),dp(9),dp(12),dp(8)); card.setBackground(shape(CARD,dp(12),0)); LinearLayout.LayoutParams clp=lp(-1,-2); clp.topMargin=dp(7); root.addView(card,clp);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); TextView label=text(name,14,WHITE,true); row.addView(label,new LinearLayout.LayoutParams(0,dp(24),1)); TextView value=text("90",14,PINK,true); row.addView(value); card.addView(row);
        SeekBar sb=new SeekBar(this); sb.setMax(100); sb.setProgress(90); sb.setProgressTintList(android.content.res.ColorStateList.valueOf(PINK)); sb.setThumbTintList(android.content.res.ColorStateList.valueOf(PINK)); card.addView(sb,lp(-1,30));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onProgressChanged(SeekBar s,int p,boolean user){value.setText(String.valueOf(p));}public void onStartTrackingTouch(SeekBar s){}public void onStopTrackingTouch(SeekBar s){}});
        sliders.put(name,sb);
    }
    private Button button(String label) { Button b=new Button(this); b.setText(label); b.setTextSize(12); b.setTextColor(WHITE); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); b.setBackground(shape(PINK,dp(12),0)); return b; }
}
